<footer>
	<div class="container">
		<div class="row">
        	<div class="col-xs-12 col-md-12 col-lg-12">
            	<div class="footer-center">
                	<h4> Voting While Living Abroad </h4>
                    <nav class="navbar navbar-expand-lg">
                    <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Terms of Services <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Privacy Policy</a>
                      </li>
                  	</ul>
                    </div>
                    </nav>
                    <p class="footer-last-text">Paid for by the Democratic National Committee <b> (202) 863-8000</b> <br> This communication is not authorized by any candidate or candidate's committee.  </p>
                    <p class="footer-last-text"> Copyright © 2020 DNC Service Corporation </p>
                </div>
            </div>
        </div>
	</div>
</footer>
</body>
</html>
<script src="js/core.min.js"></script>
    <script src="js/script.js"></script>